# Short project overview

Smart Pantry is a FastAPI/PostgreSQL backend for household food inventory with receipt OCR integration. The main documentation is now [`README.md`](README.md), which is the canonical source for architecture, directory structure, local setup, Docker Compose, migrations, tests and OCR experiments.

The code is split into `backend/` (API, business logic and database) and `ml/` (MinerU OCR service, Qwen receipt parser, OCR experiments and fixtures). See `backend/README.md` and `ml/README.md` for component-level instructions.
