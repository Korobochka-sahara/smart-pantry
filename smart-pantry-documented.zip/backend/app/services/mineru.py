'''HTTP-клиент отдельного ML OCR-сервиса.'''
import os

import httpx

from app.schemas.ocr import OCRResponse


class MinerUClient:
    def __init__(
        self,
        base_url: str | None = None,
        timeout: float = 600.0,
    ):
        self.base_url = (base_url or os.getenv(
            "MINERU_BASE_URL", "http://127.0.0.1:8001"
        )).rstrip("/")
        self.timeout = httpx.Timeout(
            connect=10.0,
            read=timeout,
            write=60.0,
            pool=10.0,
        )

    async def recognize(
        self,
        filename: str,
        content: bytes,
        content_type: str,
    ) -> OCRResponse:
        async with httpx.AsyncClient(
            timeout=self.timeout
        ) as client:
            response = await client.post(
                f"{self.base_url}/ocr",
                files={
                    "file": (
                        filename,
                        content,
                        content_type,
                    )
                },
            )

            response.raise_for_status()
            return OCRResponse.model_validate(
                response.json()
            )