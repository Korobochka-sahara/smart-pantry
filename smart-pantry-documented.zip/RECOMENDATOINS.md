# Project notes / recommendations

This file is retained as a working-notes document. Canonical setup and usage instructions belong in the root `README.md`; backend-specific notes belong in `backend/README.md`, and OCR experiments in `ml/ocr/README.md`.

Before committing project changes:

1. Run backend tests against the dedicated `smart_pantry_test` database.
2. Run ML fixture tests; the Qwen parser test requires a running Ollama service and `qwen2.5:7b-instruct`.
3. Check that only `backend/requirements.txt` and `ml/requirements.txt` are used as dependency manifests.
4. Verify Docker build and health endpoints with `docker compose up --build`.
5. Never commit real `.env` values or private receipt data.
